/**************************************************************
 * main.c
 * rev 1.0 $dt $user
 * $project
 * ***********************************************************/

#include "pico/stdlib.h"
#include <stdbool.h>
$includes

int main(void) {
  // TODO - Initialise components and variables
  while (true) {
    // TODO - Repeated code here
  }
}
